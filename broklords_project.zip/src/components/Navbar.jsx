import React from 'react';

export default function Navbar() {
  return (
    <nav
      className="d-flex justify-content-between align-items-center px-4 py-3"
      style={{
        backgroundColor: '#18182a',
        color: 'white',
        position: 'fixed',
        width: '100%',
        top: 0,
        zIndex: 999,
        boxShadow: '0 2px 10px rgba(0,0,0,0.4)',
      }}
    >
      <div className="d-flex flex-column">
        <h4 className="mb-0 fw-bold" style={{ fontSize: '1.3rem' }}>BROKLORDS</h4>
        <span
          style={{
            color: '#bbb',
            fontSize: '0.8rem',
            marginTop: '-2px',
            letterSpacing: '0.4px',
            fontWeight: 400,
          }}
        >
          We don’t just build hype / We build movements
        </span>
      </div>

      <div className="d-flex gap-4">
        <a href="#services">Services</a>
<a href="#team">Team</a>
<a href="#projects">Projects</a>
<a href="#contact">Contact</a>

      </div>
    </nav>
  );
}
