import React, { useEffect, useRef } from 'react';

export default function Hero() {
  const videoRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const scrollHeight = document.body.scrollHeight - window.innerHeight;

      const scrollFraction = scrollTop / scrollHeight;
      const video = videoRef.current;

      if (video && video.duration) {
        video.currentTime = scrollFraction * video.duration;
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section style={{ height: '200vh', backgroundColor: '#000' }}>
      <video
        ref={videoRef}
        src="/bg.mp4"
        muted
        playsInline
        preload="auto"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          zIndex: -1,
        }}
      />

      <div
        style={{
          height: '100vh',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          color: 'white',
          flexDirection: 'column',
          textAlign: 'center',
          zIndex: 2,
          position: 'relative',
        }}
      >
        <h1 className="display-3 fw-bold">BROKLORDS</h1>
        <p className="lead">We don’t just build hype — we build movements in Web3.</p>
      </div>
    </section>
  );
}
